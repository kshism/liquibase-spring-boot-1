# 📘 JsonExtractor — Fast JSON → NDJSON Extractor

**JsonExtractor** is a high-performance, streaming JSON parser written in Java.  
It efficiently extracts each object from a large JSON array (like `"accounts"`, `"users"`, `"items"`, etc.) and writes them as **newline-delimited JSON (NDJSON)** — one record per line.

This tool is designed for **massive JSON files (multi-GB)** where traditional parsers (like Jackson or Gson) fail due to memory limits.

---

## 🚀 Key Features

| Feature | Description |
|----------|-------------|
| 🔍 **Streaming JSON Parser** | Processes arbitrarily large files using efficient byte-level parsing. |
| 🧠 **Zero Object Overhead** | No DOM parsing — reads and extracts records directly from byte stream. |
| ⚙️ **Customizable Array Key** | Use `--key <name>` to specify which JSON array to extract (default: `"accounts"`). |
| 📄 **NDJSON Output** | Writes one object per line for easy downstream ingestion. |
| 🧩 **Split Output** | Split massive data into multiple `.ndjson` files with `--split <n>`. |
| ⏱ **Progress Reporting** | Optional `--progress` flag for real-time stats every 1000 records. |
| 🧮 **Count-Only Mode** | Use `--count-only` to print record count and exit without writing files. |
| ⚙️ **Configurable Buffer** | Adjust runtime I/O buffer size using `--buffer <bytes>`. |
| 🧯 **Safe Memory Limit** | Aborts on objects >10 MB to protect from malformed data. |
| 🆘 **Helpful CLI** | Type `--help` for usage, examples, and tips. |

---

## 🧩 Project Structure

```
JsonExtractor/
├── src/
│   └── com/example/JsonExtractor/
│       └── JsonExtractor.java
└── README.md
```

---

## 🧰 Requirements

- **Java 11+** (tested up to Java 21)
- No dependencies — pure Java I/O

---

## ⚙️ Build & Run

### 🧱 Compile
```bash
javac -d out src/com/example/JsonExtractor/JsonExtractor.java
```

### ▶️ Run
```bash
java -cp out com.example.JsonExtractor.JsonExtractor \
  --in input.json \
  --out extracted/output
```

---

## ⚡ Command-Line Options

| Option | Description |
|---------|-------------|
| `--help`, `-h` | Print help and usage examples |
| `--in <file>` | Input JSON file (must contain a JSON array) |
| `--out <prefix>` | Output NDJSON prefix for generated files |
| `--key <name>` | JSON array key to extract (default: `"accounts"`) |
| `--split <N>` | Split output into files of N records each |
| `--buffer <bytes>` | Set custom read buffer size (default: 65,536) |
| `--progress` | Print progress every 1000 records |
| `--count-only` | Count records and print total without writing files |

---

## 🧪 Usage Examples

### ✅ Extract all `accounts` into a single NDJSON file
```bash
java -cp out com.example.JsonExtractor.JsonExtractor \
  --in data/accounts.json \
  --out output/accounts
```

Output:
```
output/accounts.part0001.ndjson
```

### 🧩 Extract from a different JSON key
```bash
java -cp out com.example.JsonExtractor.JsonExtractor \
  --in data/people.json \
  --key users \
  --out output/users
```

Output:
```
output/users.part0001.ndjson
```

### ⚙️ Increase performance with larger buffer
```bash
java -cp out com.example.JsonExtractor.JsonExtractor \
  --in massive.json \
  --out out/massive \
  --buffer 262144
```

### ⏱ Enable progress output
```bash
java -cp out com.example.JsonExtractor.JsonExtractor \
  --in data.json \
  --out out/data \
  --split 10000 \
  --progress
```

Example log:
```
[Config] Buffer size set to 262144 bytes
[Progress] 1,000 records written (elapsed: 1.8 s)
[Progress] 2,000 records written (elapsed: 3.6 s)
...
Done. Wrote 120,000 records.
```

### 🔢 Count-only mode (no output files)
```bash
java -cp out com.example.JsonExtractor.JsonExtractor \
  --in large.json \
  --key users \
  --count-only
```

Output:
```
Total records under key "users": 1,582,330
```

---

## 🧮 Performance Tips

| Setting | Recommendation |
|----------|----------------|
| **Buffer Size** | HDD: 64–256 KB, SSD: 256–1024 KB |
| **JVM Options** | `-Xmx2g -Xms2g -XX:+UseG1GC` for large files |
| **Storage** | Use local SSD/NVMe for maximum throughput |
| **Parallelism** | Run multiple instances on separate input chunks |

---

## 🧾 Output Format

Each `.ndjson` file contains one JSON object per line, like this:

```json
{"accid":998269046,"details":{"field_1":922570,"field_2":35806.132}}
{"accid":998269047,"details":{"field_1":822571,"field_2":12406.555}}
{"accid":998269048,"details":{"field_1":745871,"field_2":77406.774}}
```

---

## 🧰 Troubleshooting

| Issue | Resolution |
|--------|-------------|
| `Could not find array for key` | Verify that the specified key exists in JSON file |
| Partial extraction | JSON may be malformed — validate with `jq .` or `jsonlint` |
| Slow progress | Increase buffer size or use SSD storage |
| Memory errors | Ensure object size <10 MB or increase JVM heap |

---

## 🧑‍💻 Author

Developed for high-throughput JSON parsing in data pipelines and LLM preprocessing.  
Optimized for low memory usage and fast disk I/O.

---

## 🧾 License

**MIT License** — Free to use, modify, and distribute with attribution.
